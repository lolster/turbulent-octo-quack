package huffmancoding;

import huffmancoding.HuffmanTree;
import huffmancoding.BinOut;

import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.lang.String;
import java.util.Arrays;

public class HuffmanCoding {
	private HuffmanCoding() {} //do not instantiate

	public static File compress(File inputFile) throws Exception {
		BufferedReader reader = new BufferedReader(new FileReader(inputFile));
		String temp = "";
		String inputRaw = "";
		while( (temp = reader.readLine()) != null) {
			inputRaw += temp + "\n";
		}
		System.out.println(inputRaw);
		inputRaw = inputRaw.substring(0, inputRaw.length() - 1);
		HuffmanTree tree = new HuffmanTree(inputRaw + '\0');
		File outputFile = new File(inputFile.getName() + ".ar");
		//outputFile.createNewFile();
		FileWriter writer = new FileWriter(outputFile);
		temp = getString(tree.getCharacters());
		//System.out.println(temp);
		writer.write(temp + "\n");
		temp = getString(tree.getCodes());
		//System.out.println(temp);
		writer.write(temp + "\n");
		temp = tree.getEncodedMessage();
		//System.out.println(temp);
		writer.write(temp);
		//BinOut.write(outputFile, tree.getEncodedMessage());
		reader.close();
		writer.close();
		return outputFile;
	}

	/*later
	public static File decompress(File inputFile) {
		//check the file type!
		//maybe not necessary
		//do your thing
	}*/

	private static String getString(char[] array) {
		String res = "";
		//System.out.println(Arrays.toString(array));
		for(char object : array) {
			res += object + " ";
			//res += object;
		}
		return res.substring(0, res.length() - 1);
		//return res;
	}

	private static String getString(String[] array) {
		String res = "";
		//System.out.println(Arrays.toString(array));
		for(String object : array) {
			res += object + " ";
			//res += object;
		}
		return res.substring(0, res.length() - 1);
		//return res;
	}

	/*later
	private static String[] split(String input) {
		ArrayList<String> list = new ArrayList<>();
		for(int i = 0; i < input.length(); i+=2) {
			list.add("" + input.charAt(i));
		}
		return list.toArray(new String[list.size()]);
	}*/
}